import React, { useState } from 'react';
import { Calculator, DollarSign, Zap, Home, ThermometerSun } from 'lucide-react';

interface EnergyData {
  [key: string]: number;
  heating: number;
  cooling: number;
  waterHeating: number;
  appliances: number;
  lighting: number;
}

function App() {
  const [monthlyBill, setMonthlyBill] = useState<number>(200);
  const [homeSize, setHomeSize] = useState<number>(2000);
  const [savings, setSavings] = useState<EnergyData | null>(null);

  const calculateSavings = () => {
    // Typical energy usage breakdown (simplified)
    const yearlyBill = monthlyBill * 12;
    const calculatedSavings: EnergyData = {
      heating: yearlyBill * 0.29 * 0.2, // 29% heating, 20% potential savings
      cooling: yearlyBill * 0.17 * 0.15, // 17% cooling, 15% potential savings
      waterHeating: yearlyBill * 0.14 * 0.1, // 14% water heating, 10% potential savings
      appliances: yearlyBill * 0.13 * 0.12, // 13% appliances, 12% potential savings
      lighting: yearlyBill * 0.12 * 0.25, // 12% lighting, 25% potential savings
    };
    setSavings(calculatedSavings);
  };

  const totalSavings = savings
    ? Object.values(savings).reduce((acc, curr) => acc + curr, 0)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center gap-3 mb-8">
            <Calculator className="w-8 h-8 text-green-600" />
            <h1 className="text-3xl font-bold text-gray-800">Energy Savings Calculator</h1>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Monthly Energy Bill ($)
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="number"
                    value={monthlyBill}
                    onChange={(e) => setMonthlyBill(Number(e.target.value))}
                    className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Home Size (sq ft)
                </label>
                <div className="relative">
                  <Home className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="number"
                    value={homeSize}
                    onChange={(e) => setHomeSize(Number(e.target.value))}
                    className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  />
                </div>
              </div>

              <button
                onClick={calculateSavings}
                className="w-full bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
              >
                <Zap className="w-5 h-5" />
                Calculate Savings
              </button>
            </div>

            {savings && (
              <div className="bg-gray-50 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">
                  Estimated Annual Savings
                </h2>
                <div className="space-y-4">
                  {Object.entries(savings).map(([category, amount]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="capitalize text-gray-600">
                        {category.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                      <span className="font-semibold text-gray-800">
                        ${amount.toFixed(2)}
                      </span>
                    </div>
                  ))}
                  <div className="border-t pt-4 mt-4">
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span className="text-green-600">Total Potential Savings</span>
                      <span className="text-green-600">${totalSavings.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-blue-50 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <ThermometerSun className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-800">Energy Saving Tips</h2>
            </div>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Install a programmable thermostat to optimize heating and cooling</li>
              <li>Upgrade to LED light bulbs for better efficiency</li>
              <li>Seal air leaks around windows and doors</li>
              <li>Regular maintenance of HVAC systems</li>
              <li>Use energy-efficient appliances</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;